import React from "react";

{/* Template Source: https://github.com/nutboltu/react-search-field */}

class Personal extends React.Component {
    constructor(props){
        super(props);
    }

    render(){
        return (
            <header>
                <h1>
                    I am not sure what goes in here...
                    maybe personal info (id, sex, job, self introduction)
                    joined Posts and posted Posts
                </h1>
            </header>
        );
    }

}

export default Personal;